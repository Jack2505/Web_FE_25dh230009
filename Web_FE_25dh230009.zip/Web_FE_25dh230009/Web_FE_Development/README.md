# Nova Store — Website bán hàng Front-end

Dự án thực hành dựa trên PDF **Xây dựng FE website bán hàng bằng HTML – CSS – JS**.

## Cấu trúc
- `index.html`: Trang chủ, header, banner, danh mục, sản phẩm nổi bật, danh sách và tìm kiếm.
- `product.html`: Trang chi tiết sản phẩm.
- `cart.html`: Trang giỏ hàng.
- `css/style.css`: Giao diện responsive.
- `js/data.js`: Dữ liệu sản phẩm, định dạng giá, quản lý giỏ hàng.
- `js/app.js`: Lọc danh mục, tìm kiếm, thêm sản phẩm, đăng ký email demo.
- `js/product.js`: Trang chi tiết sản phẩm.
- `js/cart.js`: Cập nhật số lượng, xóa sản phẩm và tính tổng tiền.

## Chạy website
1. Giải nén ZIP.
2. Mở `index.html` trong trình duyệt, hoặc mở thư mục trong VS Code và chạy bằng Live Server.
3. Thử lọc danh mục, tìm kiếm, thêm sản phẩm vào giỏ, đổi số lượng và xóa sản phẩm.

## Lưu ý
Sản phẩm và giá là dữ liệu minh họa. Giỏ hàng lưu trong `localStorage`. Đăng ký email và đặt hàng chỉ là demo, chưa kết nối máy chủ, cơ sở dữ liệu hoặc thanh toán.
