document.addEventListener("DOMContentLoaded",()=>{
const grid=document.getElementById("products-grid");if(!grid)return;
let category="all",term="";
function render(){
let list=PRODUCTS.filter(p=>(category==="all"||p.category===category)&&(p.name+" "+p.categoryName).toLocaleLowerCase("vi").includes(term.toLocaleLowerCase("vi")));
grid.innerHTML=list.map(p=>`<article class="product-card"><a class="product-image" style="background:${p.color}" href="product.html?id=${p.id}">${p.label?`<span class="mini-label">${p.label}</span>`:""}${Store.art(p)}<button class="quick-add" data-add="${p.id}" aria-label="Thêm vào giỏ">+</button></a><div class="product-info"><div><h3><a href="product.html?id=${p.id}">${p.name}</a></h3><p>${p.categoryName}</p></div><span class="price">${Store.money(p.price)}</span></div></article>`).join("");
document.getElementById("count").textContent="Đang hiển thị "+list.length+" sản phẩm";document.getElementById("empty").hidden=list.length>0;grid.hidden=list.length===0;
grid.querySelectorAll("[data-add]").forEach(b=>b.onclick=e=>{e.preventDefault();e.stopPropagation();Store.add(Number(b.dataset.add));b.textContent="✓";setTimeout(()=>b.textContent="+",700)});
}
document.querySelectorAll("[data-category]").forEach(b=>b.onclick=()=>{category=b.dataset.category;document.querySelectorAll("[data-category]").forEach(x=>x.classList.toggle("selected",x===b));render()});
document.getElementById("search-form").onsubmit=e=>{e.preventDefault();term=document.getElementById("search").value.trim();render()};
document.getElementById("search").oninput=e=>{term=e.target.value.trim();render()};
document.getElementById("clear").onclick=()=>{category="all";term="";document.getElementById("search").value="";document.querySelectorAll("[data-category]").forEach(x=>x.classList.toggle("selected",x.dataset.category==="all"));render()};
document.getElementById("newsletter").onsubmit=e=>{e.preventDefault();document.getElementById("newsletter-msg").textContent="Cảm ơn bạn đã đăng ký! (Demo)";e.target.reset()};
render();
});