window.PRODUCTS = [
{id:1,name:"Urban Backpack",category:"accessories",categoryName:"Phụ kiện",price:450000,label:"BÁN CHẠY",art:"art-backpack",color:"#dce4d2",description:"Balo tối giản dành cho lịch trình hằng ngày, có kiểu dáng gọn gàng và dễ phối đồ."},
{id:2,name:"Everyday Sneakers",category:"fashion",categoryName:"Thời trang",price:790000,label:"NEW",art:"art-shoe",color:"#e7dfd4",description:"Giày sneaker phong cách cơ bản, phù hợp với nhiều bộ trang phục thường ngày."},
{id:3,name:"Minimal Watch",category:"accessories",categoryName:"Phụ kiện",price:620000,label:"",art:"art-watch",color:"#dce4dd",description:"Đồng hồ có thiết kế gọn gàng, mặt số tối giản và dây đeo dễ phối hợp."},
{id:4,name:"Wireless Headphones",category:"tech",categoryName:"Công nghệ",price:990000,label:"NỔI BẬT",art:"art-headphone",color:"#eadbd3",description:"Tai nghe không dây với thiết kế ôm tai, phù hợp nghe nhạc và giải trí mỗi ngày."},
{id:5,name:"Daily Essential Tee",category:"fashion",categoryName:"Thời trang",price:250000,label:"",art:"art-shirt",color:"#e8e5da",description:"Áo thun kiểu dáng cơ bản, dễ kết hợp với nhiều trang phục."},
{id:6,name:"Pocket Earbuds",category:"tech",categoryName:"Công nghệ",price:550000,label:"",art:"art-earbuds",color:"#dce3d9",description:"Tai nghe nhỏ gọn để mang theo khi đi học, đi làm hoặc di chuyển."},
{id:7,name:"Canvas Daypack",category:"accessories",categoryName:"Phụ kiện",price:390000,label:"",art:"art-backpack",color:"#e8ddcf",description:"Balo vải canvas phong cách casual, phù hợp cho vật dụng hằng ngày."},
{id:8,name:"Studio Headset",category:"tech",categoryName:"Công nghệ",price:850000,label:"",art:"art-headphone",color:"#dfe3e8",description:"Tai nghe chụp tai có kiểu dáng hiện đại, thích hợp cho nhu cầu giải trí."}
];
window.Store = {
money:n=>new Intl.NumberFormat("vi-VN").format(n)+"đ",
cart:()=>{try{return JSON.parse(localStorage.getItem("nova-cart"))||[]}catch(e){return[]}},
save:c=>{localStorage.setItem("nova-cart",JSON.stringify(c));Store.updateCount()},
add:(id,q=1)=>{let c=Store.cart(),i=c.find(x=>x.id===id);if(i)i.quantity+=q;else c.push({id,quantity:q});Store.save(c)},
updateCount:()=>{let n=Store.cart().reduce((s,x)=>s+x.quantity,0);document.querySelectorAll("#cart-count").forEach(e=>e.textContent=n)},
art:p=>'<div class="product-art '+p.art+'"></div>',
find:id=>PRODUCTS.find(p=>p.id===Number(id))
};
document.addEventListener("DOMContentLoaded",()=>{Store.updateCount();let m=document.getElementById("menu"),n=document.getElementById("nav");if(m&&n)m.onclick=()=>n.classList.toggle("open")});
