document.addEventListener("DOMContentLoaded",()=>{
const root=document.getElementById("cart-items");
function render(){
let cart=Store.cart().map(i=>({p:Store.find(i.id),q:i.quantity})).filter(i=>i.p),qty=cart.reduce((s,i)=>s+i.q,0),total=cart.reduce((s,i)=>s+i.p.price*i.q,0);
document.getElementById("cart-label").textContent=qty+" sản phẩm";document.getElementById("qty").textContent=qty;document.getElementById("subtotal").textContent=Store.money(total);document.getElementById("total").textContent=Store.money(total);
if(!cart.length){root.innerHTML='<div class="empty"><div style="font-size:38px">🛒</div><h2>Giỏ hàng đang trống</h2><p>Hãy chọn vài món đồ bạn thích nhé.</p><a class="btn" href="index.html#products">Khám phá sản phẩm →</a></div>';return}
root.innerHTML=cart.map(i=>`<article class="cart-item"><div class="cart-item-art" style="background:${i.p.color}">${Store.art(i.p)}</div><div><h3><a href="product.html?id=${i.p.id}">${i.p.name}</a></h3><p>${i.p.categoryName}</p><div class="quantity"><button data-minus="${i.p.id}">−</button><span>${i.q}</span><button data-plus="${i.p.id}">+</button></div></div><div class="cart-price">${Store.money(i.p.price*i.q)}<button class="remove" data-remove="${i.p.id}">Xóa</button></div></article>`).join("");
root.querySelectorAll("[data-minus]").forEach(b=>b.onclick=()=>change(+b.dataset.minus,-1));root.querySelectorAll("[data-plus]").forEach(b=>b.onclick=()=>change(+b.dataset.plus,1));root.querySelectorAll("[data-remove]").forEach(b=>b.onclick=()=>{Store.save(Store.cart().filter(i=>i.id!==+b.dataset.remove));render()});
}
function change(id,d){let c=Store.cart(),i=c.find(x=>x.id===id);if(i)i.quantity+=d;Store.save(c.filter(x=>x.quantity>0));render()}
document.getElementById("checkout").onclick=()=>alert(Store.cart().length?"Đây là bản demo học tập. Chức năng đặt hàng và thanh toán chưa được kết nối.":"Giỏ hàng đang trống. Hãy chọn sản phẩm trước nhé.");
render();
});